let idade = 28;

console.log('Israel tem ', idade, 'anos de idade.');