//declaracao const nao pode ser alterada

const pi = 3.14;
pi = 3.1415; // vai dar erro
