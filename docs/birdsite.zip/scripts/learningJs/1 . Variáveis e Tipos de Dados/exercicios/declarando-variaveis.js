// rode no terminal com node learning.js

// 1. Declare três variáveis:
// Uma com seu nome (string)

// Uma com sua idade (number)

// Uma com o valor de "está estudando JavaScript" (boolean)

let nome = "Israel";
let idade = 28;
let estudanteJs = true;

console.log(nome, typeof nome); 
console.log(idade, typeof idade); 
console.log('variavel 3:', typeof estudanteJs);