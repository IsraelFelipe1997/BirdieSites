let x = 10;
let y = 20;
let z = 0;
z = x + y;
console.log(z);

// (10 + 5) * 3 / (2 + 1)
let calculate = (10 + 5) * 3 / (2 + 1)
console.log(calculate)

// comparacao de tipos
let numero = 5;
let texto = "5";
console.log(numero === texto)

// Use para decidir se deve sair de casa ou não
let temSol = true;
let temChuva = false;
