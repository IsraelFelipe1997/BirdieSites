let testenull = null;

console.log(testenull);

testenull = 'ALguma coisa';

console.log(testenull);