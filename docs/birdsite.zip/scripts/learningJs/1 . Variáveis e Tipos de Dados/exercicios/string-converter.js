let resultado = Number("123") + 7
console.log(resultado)
